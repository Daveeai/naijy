-- ============================================================
-- NAIJY.NG — SUPABASE DATABASE SETUP
-- Run this in: supabase.com → your project → SQL Editor → New Query
-- Paste everything → click Run
-- ============================================================

-- 1. GOMENTWATCH
CREATE TABLE IF NOT EXISTS gomentwatch (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  ref text, title text NOT NULL, type text, state text, lga text,
  description text, agency text, evidence text,
  reporter_name text DEFAULT 'Anonymous', reporter_phone text,
  status text DEFAULT 'Submitted', created_at timestamptz DEFAULT now()
);
ALTER TABLE gomentwatch ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_gomentwatch" ON gomentwatch FOR SELECT USING (true);
CREATE POLICY "public_insert_gomentwatch" ON gomentwatch FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_gomentwatch" ON gomentwatch FOR UPDATE USING (true);

-- 2. SAFENATION
CREATE TABLE IF NOT EXISTS safenation (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  ref text, title text NOT NULL, type text, severity text DEFAULT 'moderate',
  state text, location text, description text,
  reporter_name text DEFAULT 'Anonymous', status text DEFAULT 'Active',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE safenation ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_safenation" ON safenation FOR SELECT USING (true);
CREATE POLICY "public_insert_safenation" ON safenation FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_safenation" ON safenation FOR UPDATE USING (true);

-- 3. FLOWSTREAM
CREATE TABLE IF NOT EXISTS flowstream (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  content text NOT NULL, tag text DEFAULT 'thoughts',
  author_name text DEFAULT 'Anonymous', likes integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE flowstream ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_flowstream" ON flowstream FOR SELECT USING (true);
CREATE POLICY "public_insert_flowstream" ON flowstream FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_flowstream" ON flowstream FOR UPDATE USING (true);

-- 4. LOVESTORIES (WifeyMet + HusbyMet)
CREATE TABLE IF NOT EXISTS lovestories (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  type text DEFAULT 'wifey', title text NOT NULL, where_met text,
  state text, years_together integer, story text NOT NULL,
  author_name text DEFAULT 'Anonymous', hearts integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE lovestories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_lovestories" ON lovestories FOR SELECT USING (true);
CREATE POLICY "public_insert_lovestories" ON lovestories FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_lovestories" ON lovestories FOR UPDATE USING (true);

-- 5. AGRICONET LISTINGS
CREATE TABLE IF NOT EXISTS agriconet_listings (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  produce_name text NOT NULL, category text, unit text, price text,
  quantity_available text, state text, lga text, description text,
  farmer_name text NOT NULL, whatsapp text NOT NULL,
  is_available boolean DEFAULT true, created_at timestamptz DEFAULT now()
);
ALTER TABLE agriconet_listings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_agriconet_listings" ON agriconet_listings FOR SELECT USING (true);
CREATE POLICY "public_insert_agriconet_listings" ON agriconet_listings FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_agriconet_listings" ON agriconet_listings FOR UPDATE USING (true);

-- 6. AGRICONET ORDERS
CREATE TABLE IF NOT EXISTS agriconet_orders (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  item_needed text NOT NULL, quantity text, budget text,
  delivery_state text, needed_by text, notes text,
  buyer_name text NOT NULL, whatsapp text NOT NULL,
  status text DEFAULT 'Open', created_at timestamptz DEFAULT now()
);
ALTER TABLE agriconet_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_agriconet_orders" ON agriconet_orders FOR SELECT USING (true);
CREATE POLICY "public_insert_agriconet_orders" ON agriconet_orders FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_agriconet_orders" ON agriconet_orders FOR UPDATE USING (true);

-- 7. IBOPRENTICE
CREATE TABLE IF NOT EXISTS iboprentice (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  type text DEFAULT 'skill',
  title text NOT NULL, category text, state text, lga text,
  description text, experience_years integer, price_per_month text,
  availability text, name text NOT NULL, whatsapp text NOT NULL,
  likes integer DEFAULT 0, created_at timestamptz DEFAULT now()
);
ALTER TABLE iboprentice ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_iboprentice" ON iboprentice FOR SELECT USING (true);
CREATE POLICY "public_insert_iboprentice" ON iboprentice FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_iboprentice" ON iboprentice FOR UPDATE USING (true);

-- DONE. 7 tables created. Now upload the HTML files to GitHub.
